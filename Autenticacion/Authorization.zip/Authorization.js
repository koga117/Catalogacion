const jwt = require('jsonwebtoken');

// Función auxiliar para agregar encabezados CORS
const addCorsHeaders = (response) => ({
    ...response,
    headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        ...response.headers
    }
});

exports.handler = async (event) => {
    const token = event.headers.Authorization || event.headers.authorization;

    if (!token) {
        return addCorsHeaders({
            statusCode: 403,
            body: JSON.stringify({ message: 'No se proporcionó token' })
        });
    }

    try {
        const decoded = jwt.verify(token, 'SECRET_KEY');
        return addCorsHeaders({
            statusCode: 200,
            body: JSON.stringify({ message: 'Token válido', user: decoded })
        });
    } catch (err) {
        console.error("Error de verificación del token:", err);
        return addCorsHeaders({
            statusCode: 401,
            body: JSON.stringify({ message: 'Token inválido' })
        });
    }
};
