const bcrypt = require('bcryptjs');
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient({
    endpoint: 'http://host.docker.internal:4566',
    region: 'us-east-1',
    accessKeyId: 'test',
    secretAccessKey: 'test'
});

// Función auxiliar para agregar encabezados CORS
const addCorsHeaders = (response) => ({
    ...response,
    headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        ...response.headers
    }
});

exports.handler = async (event) => {
    const { username, email, password } = JSON.parse(event.body);

    if (!username || !email || !password) {
        return addCorsHeaders({
            statusCode: 400,
            body: JSON.stringify({ message: 'Todos los campos son obligatorios' })
        });
    }

    console.log("Datos recibidos:", username, email);
    console.log("Iniciando hash de contraseña...");

    try {
        const hashedPassword = await bcrypt.hash(password, 8);
        console.log("Contraseña hasheada:", hashedPassword);

        const params = {
            TableName: 'Users',
            Item: {
                userId: new Date().getTime().toString(),
                username,
                email,
                password: hashedPassword
            }
        };

        await dynamoDb.put(params).promise();

        return addCorsHeaders({
            statusCode: 201,
            body: JSON.stringify({ message: 'Usuario registrado exitosamente' })
        });
    } catch (error) {
        console.error("Error al registrar el usuario:", error);
        return addCorsHeaders({
            statusCode: 500,
            body: JSON.stringify({ message: 'Error interno del servidor' })
        });
    }
};
