const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient({
    endpoint: 'http://host.docker.internal:4566',
    region: 'us-east-1',
    accessKeyId: 'test',
    secretAccessKey: 'test'
});

// Función auxiliar para agregar encabezados CORS
const addCorsHeaders = (response) => ({
    ...response,
    headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        ...response.headers
    }
});

exports.handler = async (event) => {
    const { email, password } = JSON.parse(event.body);

    const params = {
        TableName: 'Users',
        IndexName: 'email-index',
        KeyConditionExpression: 'email = :email',
        ExpressionAttributeValues: {
            ':email': email
        }
    };

    try {
        const result = await dynamoDb.query(params).promise();
        const Item = result.Items[0];

        if (!Item) {
            return addCorsHeaders({
                statusCode: 401,
                body: JSON.stringify({ message: 'Credenciales inválidas' })
            });
        }

        // Comparar contraseñas
        const isValidPassword = await bcrypt.compare(password, Item.password);
        if (!isValidPassword) {
            return addCorsHeaders({
                statusCode: 401,
                body: JSON.stringify({ message: 'Credenciales inválidas' })
            });
        }

        const token = jwt.sign({ email: Item.email, userId: Item.userId }, 'SECRET_KEY', { expiresIn: '1h' });

        return addCorsHeaders({
            statusCode: 200,
            body: JSON.stringify({ token })
        });
    } catch (error) {
        console.error(error);
        return addCorsHeaders({
            statusCode: 500,
            body: JSON.stringify({ message: 'Error interno del servidor' })
        });
    }
};
